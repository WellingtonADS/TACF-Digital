declare module "qrcode";
